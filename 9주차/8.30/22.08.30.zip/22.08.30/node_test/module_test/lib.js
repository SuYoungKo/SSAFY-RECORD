const friends = {
  name1: "철수",
  name2: "영희",
  run: (word)=>console.log(word,"가자"),
};

module.exports = friends;