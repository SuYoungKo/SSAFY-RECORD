const { name1, name2 } = require("./lib");
//모듈애서 다른 js파일을 가져올떄 확장자를 안쓰는 관습이 있다.
console.log(name1, name2);
