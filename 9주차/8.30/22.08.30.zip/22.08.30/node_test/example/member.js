const member = {
  a: 30,
  b: 50,
};

module.exports = member;
